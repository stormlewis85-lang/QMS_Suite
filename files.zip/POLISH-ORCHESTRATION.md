# PFMEA Suite - Polish & Harden Orchestration

## Overview

This is the "Remastered Box Set" phase - taking a working prototype and making it enterprise-ready.

**Current State:** Organic Replit-origin app with broad features but architectural debt
**Target State:** Production-ready enterprise QMS with proper testing, security, and maintainability

---

## The Problem Summary

From Chrome review:
- 5 API endpoints returning 500 errors (core features broken)
- 8+ API endpoints missing (UI exists, backend doesn't)
- Near-zero test coverage for safety-critical system
- No CSRF/rate limiting/brute force protection
- Monster components (554KB single files)
- staleTime: Infinity = data never refreshes
- No contentHash on signatures (21 CFR Part 11 violation)

---

## Phase Structure

```
PHASE 1: MAKE IT WORK (Week 1-2)
├── AGENT-FIX-API.md      → Fix 500 errors + missing endpoints
└── AGENT-FIX-DATA.md     → Schema fixes + cache settings

PHASE 2: MAKE IT SAFE (Week 3-4)  
├── AGENT-SECURITY.md     → Auth hardening + RBAC
└── AGENT-SIGNATURE.md    → 21 CFR Part 11 compliance

PHASE 3: MAKE IT TESTABLE (Week 5-6)
├── AGENT-TEST-UNIT.md    → AP calculator + auto-review tests
└── AGENT-TEST-E2E.md     → Journey tests + coverage

PHASE 4: MAKE IT MAINTAINABLE (Week 7-8)
├── AGENT-REFACTOR-1.md   → Component decomposition (CapaDetail)
├── AGENT-REFACTOR-2.md   → Component decomposition (remaining)
└── AGENT-CLEANUP.md      → Code splitting + Replit removal
```

**Estimated Total:** 60-80 hours across 9 agents

---

## Agent Files

| Agent | File | Focus | Est. Hours | Priority |
|-------|------|-------|------------|----------|
| FIX-API | AGENT-FIX-API.md | Fix 500s + implement missing routes | 6-8h | P0 |
| FIX-DATA | AGENT-FIX-DATA.md | Schema fixes + queryClient settings | 3-4h | P0 |
| SECURITY | AGENT-SECURITY.md | CSRF, rate limit, lockout, RBAC | 6-8h | P0 |
| SIGNATURE | AGENT-SIGNATURE.md | contentHash + 21 CFR Part 11 | 4-6h | P1 |
| TEST-UNIT | AGENT-TEST-UNIT.md | AP calc, auto-review, state machine | 6-8h | P1 |
| TEST-E2E | AGENT-TEST-E2E.md | Journey tests + coverage report | 4-6h | P1 |
| REFACTOR-1 | AGENT-REFACTOR-1.md | CapaDetail.tsx decomposition | 6-8h | P2 |
| REFACTOR-2 | AGENT-REFACTOR-2.md | DocumentDetail, PFMEADetail, etc. | 8-10h | P2 |
| CLEANUP | AGENT-CLEANUP.md | Code splitting + infrastructure | 4-6h | P2 |

---

## Execution Sequence

```
Week 1: Foundation Fixes
┌─────────────────┐   ┌─────────────────┐
│   FIX-API       │──▶│   FIX-DATA      │
│   500s + routes │   │   Schema + cache│
└─────────────────┘   └─────────────────┘
                              │
         ┌────────────────────┘
         ▼
Week 2-3: Security
┌─────────────────┐   ┌─────────────────┐
│   SECURITY      │──▶│   SIGNATURE     │
│   Auth harden   │   │   21 CFR 11     │
└─────────────────┘   └─────────────────┘
                              │
         ┌────────────────────┘
         ▼
Week 4-5: Testing
┌─────────────────┐   ┌─────────────────┐
│   TEST-UNIT     │──▶│   TEST-E2E      │
│   Core logic    │   │   Journeys      │
└─────────────────┘   └─────────────────┘
                              │
         ┌────────────────────┘
         ▼
Week 6-8: Maintainability
┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐
│   REFACTOR-1    │──▶│   REFACTOR-2    │──▶│   CLEANUP       │
│   CapaDetail    │   │   Other pages   │   │   Infra         │
└─────────────────┘   └─────────────────┘   └─────────────────┘
```

---

## AGENT-FIX-API.md Specification

### Scope
Fix all broken endpoints and implement missing routes.

### File Ownership
- `server/routes.ts` - ADD new routes, FIX existing
- `server/storage.ts` - ADD missing storage methods

### Broken Endpoints (500 errors)

1. **`/api/change-packages`** - List all change packages
2. **`/api/pfmeas/all`** - List all PFMEAs (not by part)
3. **`/api/control-plans/all`** - List all control plans (not by part)
4. **`/api/auto-review/rules`** - Get auto-review rules
5. **`/api/auto-review/run`** - Execute auto-review

### Missing Endpoints (404s)

6. **`/api/signatures`** - CRUD for e-signatures
7. **`/api/rating-scales`** - CRUD for S/O/D rating scales
8. **`/api/gage-library`** - CRUD for gages
9. **`/api/action-items`** - CRUD for action items
10. **`/api/settings`** - User/org settings
11. **`/api/admin/workflows`** - Workflow definitions
12. **`/api/admin/distribution-lists`** - Distribution lists
13. **`/api/admin/document-templates`** - Document templates

### Implementation Order

```
1. Investigate 500 errors (check storage methods exist)
2. Add missing storage methods
3. Fix existing routes
4. Add new routes
5. Test each with curl
```

### Acceptance Criteria
- [ ] All 5 broken endpoints return 200 with data
- [ ] All 8 missing endpoints implemented and working
- [ ] No TypeScript errors
- [ ] Server starts cleanly
- [ ] Manual curl tests pass

### Validation Commands
```bash
npm run dev

# Test previously broken
curl http://localhost:5000/api/change-packages
curl http://localhost:5000/api/pfmeas/all
curl http://localhost:5000/api/control-plans/all
curl http://localhost:5000/api/auto-review/rules

# Test previously missing
curl http://localhost:5000/api/signatures
curl http://localhost:5000/api/rating-scales
curl http://localhost:5000/api/gage-library
curl http://localhost:5000/api/action-items
```

---

## AGENT-FIX-DATA.md Specification

### Scope
Fix schema issues and client-side data handling.

### File Ownership
- `shared/schema.ts` - Schema fixes
- `client/src/lib/queryClient.ts` - Cache settings

### Schema Fixes

1. **Standardize PKs to UUID**
   - `notifications.id` - serial → uuid
   - `documentFile.id` - serial → uuid
   - Other document tables as needed

2. **Fix notifications.entityId**
   - integer → uuid (to match other entities)

3. **Add pgEnums for constrained columns**
   - `changePackage.priority` → priorityEnum
   - `actionItem.status` → actionItemStatusEnum

4. **Add contentHash to signature table**
   ```typescript
   contentHash: text("content_hash").notNull(),
   ```

### QueryClient Fixes

Replace in `queryClient.ts`:
```typescript
// BEFORE
staleTime: Infinity,
refetchOnWindowFocus: false,

// AFTER
staleTime: 30 * 1000,        // 30 seconds
refetchOnWindowFocus: true,
retry: 3,
retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
```

### Acceptance Criteria
- [ ] All PKs are UUID type
- [ ] notifications.entityId is uuid
- [ ] Enums created for constrained text columns
- [ ] contentHash column added to signature
- [ ] queryClient has reasonable staleTime
- [ ] `npx drizzle-kit push` succeeds
- [ ] Server starts

---

## AGENT-SECURITY.md Specification

### Scope
Authentication and authorization hardening.

### File Ownership
- `server/routes.ts` - Add middleware
- `server/middleware/` - New directory for auth middleware
- `shared/schema.ts` - Add security columns to user table

### Tasks

1. **Rate Limiting**
   ```bash
   npm install express-rate-limit
   ```
   - 100 requests/15min for general API
   - 5 attempts/15min for login

2. **CSRF Protection**
   ```bash
   npm install csurf
   ```
   - Add CSRF token to all state-changing requests

3. **Account Lockout**
   Add to user table:
   ```typescript
   failedLoginAttempts: integer("failed_login_attempts").default(0),
   accountLockedUntil: timestamp("account_locked_until"),
   lastLoginAt: timestamp("last_login_at"),
   ```
   - Lock after 5 failed attempts for 15 minutes

4. **RBAC Middleware**
   ```typescript
   const requireRole = (...roles: string[]) => (req, res, next) => {
     if (!req.user || !roles.includes(req.user.role)) {
       return res.status(403).json({ error: 'Forbidden' });
     }
     next();
   };
   ```
   Apply to sensitive routes (delete, approve, admin)

5. **Session Hardening**
   - Regenerate session on login
   - Set secure cookie flags

### Acceptance Criteria
- [ ] Rate limiting active on all routes
- [ ] CSRF tokens required for POST/PATCH/DELETE
- [ ] Account lockout working after 5 failed logins
- [ ] RBAC middleware applied to admin routes
- [ ] No regression in existing functionality

---

## AGENT-SIGNATURE.md Specification

### Scope
21 CFR Part 11 electronic signature compliance.

### File Ownership
- `shared/schema.ts` - Signature table updates
- `server/storage.ts` - Signature methods
- `server/routes.ts` - Signature endpoints
- `server/utils/hash.ts` - New file for hashing

### Tasks

1. **Content Hash Utility**
   ```typescript
   // server/utils/hash.ts
   import crypto from 'crypto';
   
   export function computeContentHash(content: object): string {
     const canonical = JSON.stringify(content, Object.keys(content).sort());
     return crypto.createHash('sha256').update(canonical).digest('hex');
   }
   ```

2. **Update Signature Table**
   Already done in FIX-DATA, but ensure:
   - contentHash is NOT NULL
   - signedAt uses server timestamp (not client)

3. **Signature Validation**
   - On create: compute hash, store with signature
   - On verify: recompute hash, compare

4. **Audit Integration**
   - Log all signature events
   - Include verification results

### Acceptance Criteria
- [ ] computeContentHash function works correctly
- [ ] Signatures include contentHash
- [ ] Verification endpoint compares hashes
- [ ] Audit trail for all signature events
- [ ] Cannot create signature without valid content

---

## AGENT-TEST-UNIT.md Specification

### Scope
Unit tests for critical business logic.

### File Ownership
- `tests/unit/` - New directory
- `vitest.config.ts` or `jest.config.ts` - Test config

### Test Coverage

1. **AP Calculator (15 tests)**
   - All AIAG-VDA 2019 matrix combinations
   - S=9-10 with any O/D = High
   - S=1 with any O/D = Low
   - Edge cases and boundaries

2. **Auto-Review Rules (12 tests)**
   - PFD→PFMEA coverage check
   - PFMEA→CP coverage check
   - AP recompute check
   - Detection-only with S≥7
   - CSR with capability targets
   - Document control checks

3. **Change Package State Machine (10 tests)**
   - Valid transitions: draft→impact_analysis→auto_review→pending_signatures→effective
   - Invalid transitions rejected
   - Cancelled from any state
   - Cannot transition without required data

4. **Signature Hash Chain (8 tests)**
   - Hash computation deterministic
   - Hash changes when content changes
   - Verification passes for valid signatures
   - Verification fails for tampered content

### Acceptance Criteria
- [ ] 45+ unit tests written
- [ ] All tests pass
- [ ] Coverage report generated
- [ ] Core business logic verified

---

## AGENT-TEST-E2E.md Specification

### Scope
End-to-end journey tests.

### File Ownership
- `tests/e2e/` - New directory
- `playwright.config.ts` - Playwright config

### Journeys

1. **PFMEA Creation Journey**
   - Login → Parts → Create PFMEA → Add rows → Calculate AP → Save

2. **Control Plan Journey**
   - Create from PFMEA → Add characteristics → Link gages → Approve

3. **Change Package Journey**
   - Create → Impact Analysis → Auto-Review → Signatures → Effective

4. **Document Control Journey**
   - Upload → Review → Approve → Distribute → Acknowledge

5. **CAPA 8D Journey**
   - Create → D0-D8 progression → Closure

### Acceptance Criteria
- [ ] 5 journey tests written
- [ ] All pass in CI
- [ ] Screenshots on failure
- [ ] < 5 minute total runtime

---

## AGENT-REFACTOR-1.md Specification

### Scope
Decompose CapaDetail.tsx (554KB → multiple files)

### File Ownership
- `client/src/pages/CapaDetail.tsx` - Refactor
- `client/src/features/capa/` - New feature folder

### Target Structure
```
client/src/features/capa/
├── components/
│   ├── CapaHeader.tsx
│   ├── CapaTimeline.tsx
│   ├── D0EmergencyForm.tsx
│   ├── D1TeamForm.tsx
│   ├── D2ProblemForm.tsx
│   ├── D3ContainmentForm.tsx
│   ├── D4RootCauseForm.tsx
│   ├── D5CorrectiveForm.tsx
│   ├── D6ValidationForm.tsx
│   ├── D7PreventiveForm.tsx
│   ├── D8ClosureForm.tsx
│   ├── CapaAttachments.tsx
│   └── CapaAuditLog.tsx
├── hooks/
│   ├── useCapaData.ts
│   ├── useCapaMutations.ts
│   └── useCapaValidation.ts
├── utils/
│   └── capaHelpers.ts
└── index.ts
```

### Rules
- Each component < 300 lines
- Extract hooks for data fetching
- Extract utils for pure functions
- Keep CapaDetail.tsx as orchestrator only

### Acceptance Criteria
- [ ] CapaDetail.tsx < 200 lines
- [ ] 13 components extracted
- [ ] 3 hooks extracted
- [ ] All CAPA functionality still works
- [ ] No TypeScript errors

---

## AGENT-REFACTOR-2.md Specification

### Scope
Decompose remaining large pages.

### Target Files
| File | Current Size | Target |
|------|-------------|--------|
| DocumentDetail.tsx | 386KB | < 50KB |
| PFMEADetail.tsx | 256KB | < 50KB |
| Equipment.tsx | 249KB | < 50KB |
| ControlPlanDetail.tsx | 240KB | < 50KB |
| ControlsLibrary.tsx | 189KB | < 50KB |

### Pattern
Same as REFACTOR-1:
- Create features/{name}/ folder
- Extract components/hooks/utils
- Keep page as orchestrator

### Acceptance Criteria
- [ ] All 5 pages refactored
- [ ] Each page file < 200 lines
- [ ] All functionality preserved
- [ ] No TypeScript errors

---

## AGENT-CLEANUP.md Specification

### Scope
Infrastructure cleanup and optimization.

### Tasks

1. **Remove Replit Plugins**
   ```typescript
   // vite.config.ts - REMOVE
   import { cartographer } from "@replit/vite-plugin-cartographer";
   import { devBanner } from "@replit/vite-plugin-dev-banner";
   import { runtimeErrorModal } from "@replit/vite-plugin-runtime-error-modal";
   ```

2. **Code Splitting**
   ```typescript
   // App.tsx
   const CapaDetail = lazy(() => import('./features/capa'));
   const Documents = lazy(() => import('./features/documents'));
   // etc.
   ```

3. **Health Endpoints**
   ```typescript
   app.get('/health', (req, res) => res.json({ status: 'ok' }));
   app.get('/ready', async (req, res) => {
     const dbOk = await checkDbConnection();
     res.json({ status: dbOk ? 'ready' : 'not_ready' });
   });
   ```

4. **Structured Logging**
   ```bash
   npm install pino pino-http
   ```

5. **Remove Duplicate Dependencies**
   - Choose pdf-lib OR pdfkit (not both)
   - Remove next-themes (not a Next.js app)

### Acceptance Criteria
- [ ] No @replit/* imports
- [ ] Lazy loading on all routes
- [ ] /health and /ready endpoints
- [ ] pino logging configured
- [ ] No duplicate deps
- [ ] Bundle size reduced

---

## Validation Gates

### After FIX-API
- [ ] All 13 endpoints respond 200
- [ ] No 500 errors
- [ ] Server starts clean

### After FIX-DATA
- [ ] Schema pushes successfully
- [ ] Data refreshes in UI
- [ ] No stale data issues

### After SECURITY
- [ ] Rate limiting blocks rapid requests
- [ ] CSRF token required
- [ ] Lockout works after 5 fails
- [ ] Unauthorized actions blocked

### After SIGNATURE
- [ ] contentHash computed on sign
- [ ] Verification catches tampering
- [ ] Audit trail complete

### After TEST-UNIT
- [ ] 45+ tests passing
- [ ] Coverage > 70% for core logic

### After TEST-E2E
- [ ] 5 journeys passing
- [ ] CI integration working

### After REFACTOR-1
- [ ] CapaDetail decomposed
- [ ] All CAPA features work

### After REFACTOR-2
- [ ] All large pages decomposed
- [ ] No regressions

### After CLEANUP
- [ ] No Replit artifacts
- [ ] Bundle size < 2MB initial
- [ ] Health endpoints work

---

## Success Criteria

At completion:
- ✅ All API endpoints working (no 500s, no 404s)
- ✅ Security hardening in place
- ✅ 21 CFR Part 11 signature compliance
- ✅ 60+ tests with >70% coverage on core logic
- ✅ No component > 300 lines
- ✅ Code splitting enabled
- ✅ Production-ready infrastructure

---

## Execution Commands

```bash
# Phase 1: Make It Work
# Run AGENT-FIX-API.md
npm run dev
# Verify all endpoints with curl

# Run AGENT-FIX-DATA.md
npx drizzle-kit push
npm run dev

# Phase 2: Make It Safe
# Run AGENT-SECURITY.md
npm run dev
# Test rate limiting, CSRF, lockout

# Run AGENT-SIGNATURE.md
npm run dev
# Test signature creation and verification

# Phase 3: Make It Testable
# Run AGENT-TEST-UNIT.md
npm test

# Run AGENT-TEST-E2E.md
npm run test:e2e

# Phase 4: Make It Maintainable
# Run AGENT-REFACTOR-1.md
npm run dev
# Test CAPA features

# Run AGENT-REFACTOR-2.md
npm run dev
# Test all refactored pages

# Run AGENT-CLEANUP.md
npm run build
# Check bundle size
curl http://localhost:5000/health
```

---

## Risk Mitigation

### If agent gets stuck:
1. Check file ownership - don't touch files outside scope
2. Run `npm run dev` frequently to catch errors early
3. Git commit after each successful step

### If tests fail:
1. Check if it's a real bug or test issue
2. Fix bugs, don't skip tests
3. Document any known issues

### If refactoring breaks features:
1. Keep the old file as backup
2. Test each extraction before removing from original
3. Use feature flags if needed

---

## Post-Completion

After all phases:
1. **Full regression test** - Manual QA of all features
2. **Performance audit** - Lighthouse, bundle analysis
3. **Security scan** - npm audit, OWASP checks
4. **Documentation** - Update README, API docs
5. **Demo** - Show stakeholders the improvements
