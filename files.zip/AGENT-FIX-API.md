# AGENT-FIX-API - Fix Broken & Missing Endpoints

## Prerequisites
- Read `RALPH_PATTERNS.md` first
- Server currently running with some 500/404 errors
- This agent fixes those and adds missing functionality

---

## Mission

Fix all broken API endpoints (500 errors) and implement all missing endpoints (404 errors) that the UI expects.

---

## File Ownership

**YOU OWN:**
- `server/routes.ts` - Add/fix routes
- `server/storage.ts` - Add missing storage methods

**DO NOT TOUCH:**
- `shared/schema.ts` (FIX-DATA agent handles this)
- Any client files
- Any test files

---

## Part 1: Diagnose Broken Endpoints

### Expected 500 Errors

The Chrome review identified these endpoints returning 500:

1. `/api/change-packages` - GET list
2. `/api/pfmeas/all` - GET all PFMEAs (not by part)
3. `/api/control-plans/all` - GET all control plans (not by part)  
4. `/api/auto-review/rules` - GET review rules
5. `/api/auto-review/run` - POST run review

### Diagnosis Steps

For each broken endpoint:

1. Find the route in `routes.ts`
2. Check what storage method it calls
3. Check if that method exists in `storage.ts`
4. Check if the method has errors (wrong table name, missing import, etc.)

```bash
# Test each endpoint
curl -s http://localhost:5000/api/change-packages | head
curl -s http://localhost:5000/api/pfmeas/all | head
curl -s http://localhost:5000/api/control-plans/all | head
curl -s http://localhost:5000/api/auto-review/rules | head
curl -s -X POST http://localhost:5000/api/auto-review/run | head
```

---

## Part 2: Fix Broken Endpoints

### 2.1 Change Packages

**In storage.ts, add:**
```typescript
// Change Packages
async getAllChangePackages(): Promise<ChangePackage[]> {
  return db.select().from(changePackage).orderBy(desc(changePackage.createdAt));
}

async getChangePackageById(id: string): Promise<ChangePackage | undefined> {
  const [result] = await db.select().from(changePackage).where(eq(changePackage.id, id));
  return result;
}

async createChangePackage(data: InsertChangePackage): Promise<ChangePackage> {
  const [result] = await db.insert(changePackage).values(data).returning();
  return result;
}

async updateChangePackage(id: string, data: Partial<InsertChangePackage>): Promise<ChangePackage | undefined> {
  const [result] = await db.update(changePackage).set(data).where(eq(changePackage.id, id)).returning();
  return result;
}
```

**In routes.ts, add/fix:**
```typescript
// Change Packages API
app.get("/api/change-packages", async (req, res) => {
  try {
    const packages = await storage.getAllChangePackages();
    res.json(packages);
  } catch (error) {
    console.error("Error fetching change packages:", error);
    res.status(500).json({ error: "Failed to fetch change packages" });
  }
});

app.get("/api/change-packages/:id", async (req, res) => {
  try {
    const pkg = await storage.getChangePackageById(req.params.id);
    if (!pkg) {
      return res.status(404).json({ error: "Change package not found" });
    }
    res.json(pkg);
  } catch (error) {
    console.error("Error fetching change package:", error);
    res.status(500).json({ error: "Failed to fetch change package" });
  }
});

app.post("/api/change-packages", async (req, res) => {
  try {
    const validatedData = insertChangePackageSchema.parse(req.body);
    const newPackage = await storage.createChangePackage(validatedData);
    res.status(201).json(newPackage);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error creating change package:", error);
    res.status(500).json({ error: "Failed to create change package" });
  }
});

app.patch("/api/change-packages/:id", async (req, res) => {
  try {
    const updates = insertChangePackageSchema.partial().parse(req.body);
    const updated = await storage.updateChangePackage(req.params.id, updates);
    if (!updated) {
      return res.status(404).json({ error: "Change package not found" });
    }
    res.json(updated);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error updating change package:", error);
    res.status(500).json({ error: "Failed to update change package" });
  }
});
```

### 2.2 All PFMEAs (not by part)

**In storage.ts, add:**
```typescript
async getAllPFMEAs(): Promise<PFMEA[]> {
  return db.select().from(pfmea).orderBy(desc(pfmea.createdAt));
}
```

**In routes.ts, add:**
```typescript
app.get("/api/pfmeas/all", async (req, res) => {
  try {
    const pfmeas = await storage.getAllPFMEAs();
    res.json(pfmeas);
  } catch (error) {
    console.error("Error fetching all PFMEAs:", error);
    res.status(500).json({ error: "Failed to fetch PFMEAs" });
  }
});
```

### 2.3 All Control Plans (not by part)

**In storage.ts, add:**
```typescript
async getAllControlPlans(): Promise<ControlPlan[]> {
  return db.select().from(controlPlan).orderBy(desc(controlPlan.createdAt));
}
```

**In routes.ts, add:**
```typescript
app.get("/api/control-plans/all", async (req, res) => {
  try {
    const plans = await storage.getAllControlPlans();
    res.json(plans);
  } catch (error) {
    console.error("Error fetching all control plans:", error);
    res.status(500).json({ error: "Failed to fetch control plans" });
  }
});
```

### 2.4 Auto-Review Rules

**In storage.ts, add:**
```typescript
async getAutoReviewRules(): Promise<AutoReviewRule[]> {
  // Check if autoReviewRule table exists, if not return default rules
  try {
    return db.select().from(autoReviewRule);
  } catch {
    // Return default AIAG-VDA rules if table doesn't exist
    return [
      { id: '1', name: 'PFD→PFMEA Coverage', description: 'Every PFD step must have at least one PFMEA row', severity: 'error', enabled: true },
      { id: '2', name: 'PFMEA→CP Coverage', description: 'Every AP=High PFMEA row must have a Control Plan row or waiver', severity: 'error', enabled: true },
      { id: '3', name: 'AP Recompute', description: 'Stored AP must match calculated AP from S×O×D matrix', severity: 'warning', enabled: true },
      { id: '4', name: 'Detection-Only High Severity', description: 'S≥7 with only detection controls requires prevention controls', severity: 'error', enabled: true },
      { id: '5', name: 'CSR Capability', description: 'CSR characteristics must have Cpk targets', severity: 'warning', enabled: true },
      { id: '6', name: 'Document Control', description: 'All documents must have doc number, revision, and effective date', severity: 'error', enabled: true },
    ];
  }
}
```

**In routes.ts, add:**
```typescript
app.get("/api/auto-review/rules", async (req, res) => {
  try {
    const rules = await storage.getAutoReviewRules();
    res.json(rules);
  } catch (error) {
    console.error("Error fetching auto-review rules:", error);
    res.status(500).json({ error: "Failed to fetch auto-review rules" });
  }
});
```

### 2.5 Auto-Review Run

**In storage.ts, add:**
```typescript
interface AutoReviewResult {
  partId: string;
  pfmeaId?: string;
  controlPlanId?: string;
  findings: AutoReviewFinding[];
  summary: {
    errors: number;
    warnings: number;
    passed: number;
  };
  runAt: string;
}

interface AutoReviewFinding {
  ruleId: string;
  ruleName: string;
  severity: 'error' | 'warning' | 'info';
  message: string;
  entityType: string;
  entityId: string;
  details?: Record<string, any>;
}

async runAutoReview(partId: string, pfmeaId?: string, controlPlanId?: string): Promise<AutoReviewResult> {
  const findings: AutoReviewFinding[] = [];
  
  // Get PFMEA data
  const pfmeaData = pfmeaId ? await this.getPFMEAById(pfmeaId) : null;
  
  // Get Control Plan data
  const cpData = controlPlanId ? await this.getControlPlanById(controlPlanId) : null;
  
  // Rule 1: PFD→PFMEA Coverage
  // TODO: Implement when PFD table is available
  
  // Rule 2: PFMEA→CP Coverage (AP=High must have CP row)
  if (pfmeaData && cpData) {
    const highAPRows = pfmeaData.rows.filter(r => r.ap === 'H');
    for (const row of highAPRows) {
      const hasCPRow = cpData.rows.some(cp => cp.sourcePfmeaRowId === row.id);
      if (!hasCPRow) {
        findings.push({
          ruleId: '2',
          ruleName: 'PFMEA→CP Coverage',
          severity: 'error',
          message: `High AP PFMEA row "${row.failureMode}" has no Control Plan coverage`,
          entityType: 'pfmeaRow',
          entityId: row.id,
        });
      }
    }
  }
  
  // Rule 3: AP Recompute Check
  if (pfmeaData) {
    for (const row of pfmeaData.rows) {
      const computedAP = this.calculateAP(row.severity, row.occurrence, row.detection);
      if (computedAP !== row.ap) {
        findings.push({
          ruleId: '3',
          ruleName: 'AP Recompute',
          severity: 'warning',
          message: `PFMEA row "${row.failureMode}" AP mismatch: stored=${row.ap}, computed=${computedAP}`,
          entityType: 'pfmeaRow',
          entityId: row.id,
          details: { stored: row.ap, computed: computedAP, S: row.severity, O: row.occurrence, D: row.detection },
        });
      }
    }
  }
  
  // Rule 4: Detection-only with S≥7
  if (pfmeaData) {
    for (const row of pfmeaData.rows) {
      const preventionControls = row.preventionControls as string[] || [];
      if (row.severity >= 7 && preventionControls.length === 0) {
        findings.push({
          ruleId: '4',
          ruleName: 'Detection-Only High Severity',
          severity: 'error',
          message: `PFMEA row "${row.failureMode}" has S≥7 but no prevention controls`,
          entityType: 'pfmeaRow',
          entityId: row.id,
        });
      }
    }
  }
  
  // Rule 5: CSR with capability targets
  if (cpData) {
    for (const row of cpData.rows) {
      if (row.csrSymbol) {
        if (!row.acceptanceCriteria?.includes('Cpk')) {
          findings.push({
            ruleId: '5',
            ruleName: 'CSR Capability',
            severity: 'warning',
            message: `CSR characteristic "${row.characteristicName}" missing Cpk target`,
            entityType: 'controlPlanRow',
            entityId: row.id,
          });
        }
        if (!row.reactionPlan) {
          findings.push({
            ruleId: '5',
            ruleName: 'CSR Capability',
            severity: 'error',
            message: `CSR characteristic "${row.characteristicName}" missing reaction plan`,
            entityType: 'controlPlanRow',
            entityId: row.id,
          });
        }
      }
    }
  }
  
  // Rule 6: Document Control
  if (pfmeaData && !pfmeaData.docNo) {
    findings.push({
      ruleId: '6',
      ruleName: 'Document Control',
      severity: 'error',
      message: 'PFMEA missing document number',
      entityType: 'pfmea',
      entityId: pfmeaData.id,
    });
  }
  
  if (cpData && !cpData.docNo) {
    findings.push({
      ruleId: '6',
      ruleName: 'Document Control',
      severity: 'error',
      message: 'Control Plan missing document number',
      entityType: 'controlPlan',
      entityId: cpData.id,
    });
  }
  
  return {
    partId,
    pfmeaId,
    controlPlanId,
    findings,
    summary: {
      errors: findings.filter(f => f.severity === 'error').length,
      warnings: findings.filter(f => f.severity === 'warning').length,
      passed: 6 - new Set(findings.map(f => f.ruleId)).size,
    },
    runAt: new Date().toISOString(),
  };
}

// AIAG-VDA 2019 AP Calculator
calculateAP(S: number, O: number, D: number): 'H' | 'M' | 'L' {
  // HIGH: S ≥ 9 regardless of O or D
  if (S >= 9) return 'H';
  
  // HIGH: S = 7-8 AND O ≥ 7
  if (S >= 7 && S <= 8 && O >= 7) return 'H';
  
  // HIGH: S = 7-8 AND D ≥ 7
  if (S >= 7 && S <= 8 && D >= 7) return 'H';
  
  // HIGH: D ≥ 9 (no detection capability)
  if (D >= 9) return 'H';
  
  // MEDIUM: S = 5-6 AND (O ≥ 7 OR D ≥ 7)
  if (S >= 5 && S <= 6 && (O >= 7 || D >= 7)) return 'M';
  
  // MEDIUM: S = 7-8 AND O = 4-6 AND D = 4-6
  if (S >= 7 && S <= 8 && O >= 4 && O <= 6 && D >= 4 && D <= 6) return 'M';
  
  // LOW: All other combinations
  return 'L';
}
```

**In routes.ts, add:**
```typescript
const autoReviewRunSchema = z.object({
  partId: z.string().uuid(),
  pfmeaId: z.string().uuid().optional(),
  controlPlanId: z.string().uuid().optional(),
});

app.post("/api/auto-review/run", async (req, res) => {
  try {
    const { partId, pfmeaId, controlPlanId } = autoReviewRunSchema.parse(req.body);
    const result = await storage.runAutoReview(partId, pfmeaId, controlPlanId);
    res.json(result);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error running auto-review:", error);
    res.status(500).json({ error: "Failed to run auto-review" });
  }
});
```

---

## Part 3: Implement Missing Endpoints

### 3.1 Signatures API

**In storage.ts, add:**
```typescript
// Signatures
async getAllSignatures(): Promise<Signature[]> {
  return db.select().from(signature).orderBy(desc(signature.signedAt));
}

async getSignatureById(id: string): Promise<Signature | undefined> {
  const [result] = await db.select().from(signature).where(eq(signature.id, id));
  return result;
}

async getSignaturesByEntity(entityType: string, entityId: string): Promise<Signature[]> {
  return db.select().from(signature)
    .where(and(eq(signature.entityType, entityType), eq(signature.entityId, entityId)))
    .orderBy(desc(signature.signedAt));
}

async createSignature(data: InsertSignature): Promise<Signature> {
  const [result] = await db.insert(signature).values({
    ...data,
    signedAt: new Date(),
  }).returning();
  return result;
}
```

**In routes.ts, add:**
```typescript
// Signatures API
app.get("/api/signatures", async (req, res) => {
  try {
    const { entityType, entityId } = req.query;
    let signatures;
    if (entityType && entityId) {
      signatures = await storage.getSignaturesByEntity(entityType as string, entityId as string);
    } else {
      signatures = await storage.getAllSignatures();
    }
    res.json(signatures);
  } catch (error) {
    console.error("Error fetching signatures:", error);
    res.status(500).json({ error: "Failed to fetch signatures" });
  }
});

app.get("/api/signatures/:id", async (req, res) => {
  try {
    const sig = await storage.getSignatureById(req.params.id);
    if (!sig) {
      return res.status(404).json({ error: "Signature not found" });
    }
    res.json(sig);
  } catch (error) {
    console.error("Error fetching signature:", error);
    res.status(500).json({ error: "Failed to fetch signature" });
  }
});

app.post("/api/signatures", async (req, res) => {
  try {
    const validatedData = insertSignatureSchema.parse(req.body);
    const newSig = await storage.createSignature(validatedData);
    res.status(201).json(newSig);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error creating signature:", error);
    res.status(500).json({ error: "Failed to create signature" });
  }
});
```

### 3.2 Rating Scales API

**In storage.ts, add:**
```typescript
// Rating Scales
async getAllRatingScales(): Promise<RatingScale[]> {
  return db.select().from(ratingScale).orderBy(ratingScale.version, ratingScale.kind);
}

async getRatingScalesByVersion(version: string): Promise<RatingScale[]> {
  return db.select().from(ratingScale).where(eq(ratingScale.version, version));
}

async createRatingScale(data: InsertRatingScale): Promise<RatingScale> {
  const [result] = await db.insert(ratingScale).values(data).returning();
  return result;
}

async updateRatingScale(id: string, data: Partial<InsertRatingScale>): Promise<RatingScale | undefined> {
  const [result] = await db.update(ratingScale).set(data).where(eq(ratingScale.id, id)).returning();
  return result;
}
```

**In routes.ts, add:**
```typescript
// Rating Scales API
app.get("/api/rating-scales", async (req, res) => {
  try {
    const { version } = req.query;
    let scales;
    if (version) {
      scales = await storage.getRatingScalesByVersion(version as string);
    } else {
      scales = await storage.getAllRatingScales();
    }
    res.json(scales);
  } catch (error) {
    console.error("Error fetching rating scales:", error);
    res.status(500).json({ error: "Failed to fetch rating scales" });
  }
});

app.post("/api/rating-scales", async (req, res) => {
  try {
    const validatedData = insertRatingScaleSchema.parse(req.body);
    const newScale = await storage.createRatingScale(validatedData);
    res.status(201).json(newScale);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error creating rating scale:", error);
    res.status(500).json({ error: "Failed to create rating scale" });
  }
});
```

### 3.3 Gage Library API

**In storage.ts, add:**
```typescript
// Gage Library
async getAllGages(): Promise<GageLibrary[]> {
  return db.select().from(gageLibrary).orderBy(gageLibrary.name);
}

async getGageById(id: string): Promise<GageLibrary | undefined> {
  const [result] = await db.select().from(gageLibrary).where(eq(gageLibrary.id, id));
  return result;
}

async createGage(data: InsertGageLibrary): Promise<GageLibrary> {
  const [result] = await db.insert(gageLibrary).values(data).returning();
  return result;
}

async updateGage(id: string, data: Partial<InsertGageLibrary>): Promise<GageLibrary | undefined> {
  const [result] = await db.update(gageLibrary).set(data).where(eq(gageLibrary.id, id)).returning();
  return result;
}

async deleteGage(id: string): Promise<boolean> {
  const result = await db.delete(gageLibrary).where(eq(gageLibrary.id, id));
  return result.rowCount > 0;
}
```

**In routes.ts, add:**
```typescript
// Gage Library API
app.get("/api/gage-library", async (req, res) => {
  try {
    const gages = await storage.getAllGages();
    res.json(gages);
  } catch (error) {
    console.error("Error fetching gages:", error);
    res.status(500).json({ error: "Failed to fetch gages" });
  }
});

app.get("/api/gage-library/:id", async (req, res) => {
  try {
    const gage = await storage.getGageById(req.params.id);
    if (!gage) {
      return res.status(404).json({ error: "Gage not found" });
    }
    res.json(gage);
  } catch (error) {
    console.error("Error fetching gage:", error);
    res.status(500).json({ error: "Failed to fetch gage" });
  }
});

app.post("/api/gage-library", async (req, res) => {
  try {
    const validatedData = insertGageLibrarySchema.parse(req.body);
    const newGage = await storage.createGage(validatedData);
    res.status(201).json(newGage);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error creating gage:", error);
    res.status(500).json({ error: "Failed to create gage" });
  }
});

app.patch("/api/gage-library/:id", async (req, res) => {
  try {
    const updates = insertGageLibrarySchema.partial().parse(req.body);
    const updated = await storage.updateGage(req.params.id, updates);
    if (!updated) {
      return res.status(404).json({ error: "Gage not found" });
    }
    res.json(updated);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error updating gage:", error);
    res.status(500).json({ error: "Failed to update gage" });
  }
});

app.delete("/api/gage-library/:id", async (req, res) => {
  try {
    const success = await storage.deleteGage(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Gage not found" });
    }
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting gage:", error);
    res.status(500).json({ error: "Failed to delete gage" });
  }
});
```

### 3.4 Action Items API

**In storage.ts, add:**
```typescript
// Action Items
async getAllActionItems(): Promise<ActionItem[]> {
  return db.select().from(actionItem).orderBy(desc(actionItem.createdAt));
}

async getActionItemById(id: string): Promise<ActionItem | undefined> {
  const [result] = await db.select().from(actionItem).where(eq(actionItem.id, id));
  return result;
}

async getActionItemsByEntity(entityType: string, entityId: string): Promise<ActionItem[]> {
  return db.select().from(actionItem)
    .where(and(eq(actionItem.entityType, entityType), eq(actionItem.entityId, entityId)))
    .orderBy(actionItem.dueDate);
}

async createActionItem(data: InsertActionItem): Promise<ActionItem> {
  const [result] = await db.insert(actionItem).values(data).returning();
  return result;
}

async updateActionItem(id: string, data: Partial<InsertActionItem>): Promise<ActionItem | undefined> {
  const [result] = await db.update(actionItem).set(data).where(eq(actionItem.id, id)).returning();
  return result;
}

async deleteActionItem(id: string): Promise<boolean> {
  const result = await db.delete(actionItem).where(eq(actionItem.id, id));
  return result.rowCount > 0;
}
```

**In routes.ts, add:**
```typescript
// Action Items API
app.get("/api/action-items", async (req, res) => {
  try {
    const { entityType, entityId } = req.query;
    let items;
    if (entityType && entityId) {
      items = await storage.getActionItemsByEntity(entityType as string, entityId as string);
    } else {
      items = await storage.getAllActionItems();
    }
    res.json(items);
  } catch (error) {
    console.error("Error fetching action items:", error);
    res.status(500).json({ error: "Failed to fetch action items" });
  }
});

app.get("/api/action-items/:id", async (req, res) => {
  try {
    const item = await storage.getActionItemById(req.params.id);
    if (!item) {
      return res.status(404).json({ error: "Action item not found" });
    }
    res.json(item);
  } catch (error) {
    console.error("Error fetching action item:", error);
    res.status(500).json({ error: "Failed to fetch action item" });
  }
});

app.post("/api/action-items", async (req, res) => {
  try {
    const validatedData = insertActionItemSchema.parse(req.body);
    const newItem = await storage.createActionItem(validatedData);
    res.status(201).json(newItem);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error creating action item:", error);
    res.status(500).json({ error: "Failed to create action item" });
  }
});

app.patch("/api/action-items/:id", async (req, res) => {
  try {
    const updates = insertActionItemSchema.partial().parse(req.body);
    const updated = await storage.updateActionItem(req.params.id, updates);
    if (!updated) {
      return res.status(404).json({ error: "Action item not found" });
    }
    res.json(updated);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error updating action item:", error);
    res.status(500).json({ error: "Failed to update action item" });
  }
});

app.delete("/api/action-items/:id", async (req, res) => {
  try {
    const success = await storage.deleteActionItem(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Action item not found" });
    }
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting action item:", error);
    res.status(500).json({ error: "Failed to delete action item" });
  }
});
```

### 3.5 Settings API

**In routes.ts, add:**
```typescript
// Settings API (user preferences)
app.get("/api/settings", async (req, res) => {
  try {
    // For now, return default settings
    // TODO: Get from user session when auth is implemented
    const settings = {
      theme: 'light',
      timezone: 'America/Detroit',
      dateFormat: 'MM/DD/YYYY',
      emailNotifications: true,
      defaultAPStandard: 'AIAG-VDA-2019',
    };
    res.json(settings);
  } catch (error) {
    console.error("Error fetching settings:", error);
    res.status(500).json({ error: "Failed to fetch settings" });
  }
});

app.patch("/api/settings", async (req, res) => {
  try {
    // TODO: Persist to user record when auth is implemented
    const updates = req.body;
    res.json({ ...updates, updated: true });
  } catch (error) {
    console.error("Error updating settings:", error);
    res.status(500).json({ error: "Failed to update settings" });
  }
});
```

### 3.6 Admin APIs

**In routes.ts, add:**
```typescript
// Admin: Workflow Definitions
app.get("/api/admin/workflows", async (req, res) => {
  try {
    const workflows = await storage.getAllWorkflowDefinitions();
    res.json(workflows);
  } catch (error) {
    console.error("Error fetching workflows:", error);
    res.status(500).json({ error: "Failed to fetch workflows" });
  }
});

app.post("/api/admin/workflows", async (req, res) => {
  try {
    const validatedData = insertApprovalWorkflowDefinitionSchema.parse(req.body);
    const newWorkflow = await storage.createWorkflowDefinition(validatedData);
    res.status(201).json(newWorkflow);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error creating workflow:", error);
    res.status(500).json({ error: "Failed to create workflow" });
  }
});

// Admin: Distribution Lists
app.get("/api/admin/distribution-lists", async (req, res) => {
  try {
    const lists = await storage.getAllDistributionLists();
    res.json(lists);
  } catch (error) {
    console.error("Error fetching distribution lists:", error);
    res.status(500).json({ error: "Failed to fetch distribution lists" });
  }
});

app.post("/api/admin/distribution-lists", async (req, res) => {
  try {
    const validatedData = insertDistributionListSchema.parse(req.body);
    const newList = await storage.createDistributionList(validatedData);
    res.status(201).json(newList);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error creating distribution list:", error);
    res.status(500).json({ error: "Failed to create distribution list" });
  }
});

// Admin: Document Templates
app.get("/api/admin/document-templates", async (req, res) => {
  try {
    const templates = await storage.getAllDocumentTemplates();
    res.json(templates);
  } catch (error) {
    console.error("Error fetching document templates:", error);
    res.status(500).json({ error: "Failed to fetch document templates" });
  }
});

app.post("/api/admin/document-templates", async (req, res) => {
  try {
    const validatedData = insertDocumentTemplateSchema.parse(req.body);
    const newTemplate = await storage.createDocumentTemplate(validatedData);
    res.status(201).json(newTemplate);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: fromError(error).toString() });
    }
    console.error("Error creating document template:", error);
    res.status(500).json({ error: "Failed to create document template" });
  }
});
```

**In storage.ts, add corresponding methods:**
```typescript
// Workflow Definitions
async getAllWorkflowDefinitions(): Promise<ApprovalWorkflowDefinition[]> {
  return db.select().from(approvalWorkflowDefinition).orderBy(approvalWorkflowDefinition.name);
}

async createWorkflowDefinition(data: InsertApprovalWorkflowDefinition): Promise<ApprovalWorkflowDefinition> {
  const [result] = await db.insert(approvalWorkflowDefinition).values(data).returning();
  return result;
}

// Distribution Lists
async getAllDistributionLists(): Promise<DistributionList[]> {
  return db.select().from(distributionList).orderBy(distributionList.name);
}

async createDistributionList(data: InsertDistributionList): Promise<DistributionList> {
  const [result] = await db.insert(distributionList).values(data).returning();
  return result;
}

// Document Templates
async getAllDocumentTemplates(): Promise<DocumentTemplate[]> {
  return db.select().from(documentTemplate).orderBy(documentTemplate.name);
}

async createDocumentTemplate(data: InsertDocumentTemplate): Promise<DocumentTemplate> {
  const [result] = await db.insert(documentTemplate).values(data).returning();
  return result;
}
```

---

## Part 4: Update Imports

Make sure all new tables and types are imported at the top of both files.

**In storage.ts, add to imports:**
```typescript
import {
  // ... existing imports ...
  changePackage,
  signature,
  ratingScale,
  gageLibrary,
  actionItem,
  approvalWorkflowDefinition,
  distributionList,
  documentTemplate,
  type ChangePackage,
  type InsertChangePackage,
  type Signature,
  type InsertSignature,
  type RatingScale,
  type InsertRatingScale,
  type GageLibrary,
  type InsertGageLibrary,
  type ActionItem,
  type InsertActionItem,
  type ApprovalWorkflowDefinition,
  type InsertApprovalWorkflowDefinition,
  type DistributionList,
  type InsertDistributionList,
  type DocumentTemplate,
  type InsertDocumentTemplate,
} from "@shared/schema";
```

**In routes.ts, add to imports:**
```typescript
import {
  // ... existing imports ...
  insertChangePackageSchema,
  insertSignatureSchema,
  insertRatingScaleSchema,
  insertGageLibrarySchema,
  insertActionItemSchema,
  insertApprovalWorkflowDefinitionSchema,
  insertDistributionListSchema,
  insertDocumentTemplateSchema,
} from "@shared/schema";
```

---

## Acceptance Criteria

- [ ] `/api/change-packages` returns 200 with array
- [ ] `/api/pfmeas/all` returns 200 with array
- [ ] `/api/control-plans/all` returns 200 with array
- [ ] `/api/auto-review/rules` returns 200 with 6 rules
- [ ] `/api/auto-review/run` accepts POST and returns findings
- [ ] `/api/signatures` returns 200 with array
- [ ] `/api/rating-scales` returns 200 with array
- [ ] `/api/gage-library` returns 200 with array
- [ ] `/api/action-items` returns 200 with array
- [ ] `/api/settings` returns 200 with defaults
- [ ] `/api/admin/workflows` returns 200 with array
- [ ] `/api/admin/distribution-lists` returns 200 with array
- [ ] `/api/admin/document-templates` returns 200 with array
- [ ] No TypeScript errors
- [ ] Server starts cleanly

---

## Validation Commands

```bash
# Start server
npm run dev

# Test all endpoints
curl http://localhost:5000/api/change-packages
curl http://localhost:5000/api/pfmeas/all
curl http://localhost:5000/api/control-plans/all
curl http://localhost:5000/api/auto-review/rules
curl -X POST http://localhost:5000/api/auto-review/run -H "Content-Type: application/json" -d '{"partId":"00000000-0000-0000-0000-000000000001"}'
curl http://localhost:5000/api/signatures
curl http://localhost:5000/api/rating-scales
curl http://localhost:5000/api/gage-library
curl http://localhost:5000/api/action-items
curl http://localhost:5000/api/settings
curl http://localhost:5000/api/admin/workflows
curl http://localhost:5000/api/admin/distribution-lists
curl http://localhost:5000/api/admin/document-templates
```

All should return 200 with JSON (even if empty arrays).
