# PFMEA Suite - Replit Edition

Full-stack IATF 16949 Process FMEA application optimized for Replit deployment.

## 🎯 What This Is

A production-ready PFMEA (Process Failure Mode and Effects Analysis) suite that includes:
- **Process Library** - Manufacturing process definitions with versioning
- **PFMEA Generator** - Automated FMEA creation using AIAG-VDA 2019 methodology
- **Control Plan Generator** - Quality control plans with inspection characteristics
- **Auto-Review Engine** - Automated Action Priority (AP) calculation
- **Change Management** - Engineering change workflow with e-signatures

## 🚀 Quick Start on Replit

### Prerequisites
1. A Replit account
2. PostgreSQL database (created in Replit)

### Setup Steps

#### 1. Create PostgreSQL Database
```
1. Click "Tools" → "Database" in Replit sidebar
2. Select "PostgreSQL"
3. Click "Create Database"
4. Copy the connection string
```

#### 2. Add Environment Variables
```
1. Click "Tools" → "Secrets"
2. Add new secret:
   Key: DATABASE_URL
   Value: postgresql://[your-connection-string]
```

#### 3. Run Setup Script
```bash
chmod +x setup.sh
./setup.sh
```

#### 4. Start Development Server
```bash
npm run dev
```

Your app will be available at `https://[your-repl-name].[your-username].repl.co`

## 📁 Project Structure

```
pfmea-suite/
├── src/
│   ├── app/                    # Next.js 14 App Router
│   │   ├── page.tsx           # Home page
│   │   ├── parts/             # Parts management
│   │   ├── processes/         # Process library
│   │   ├── pfmea/             # PFMEA generator
│   │   ├── control-plans/     # Control plan generator
│   │   └── api/trpc/          # tRPC endpoint
│   │
│   ├── server/                 # Backend
│   │   ├── routers/           # tRPC routers
│   │   │   ├── parts.ts
│   │   │   ├── processes.ts
│   │   │   ├── pfmea.ts
│   │   │   └── controlPlans.ts
│   │   ├── services/          # Business logic
│   │   │   ├── pfd-generator.ts
│   │   │   ├── pfmea-generator.ts
│   │   │   ├── control-plan-generator.ts
│   │   │   └── auto-review.ts
│   │   └── trpc.ts            # tRPC configuration
│   │
│   ├── db/                     # Database
│   │   ├── schema/            # Drizzle schema
│   │   │   ├── parts.ts
│   │   │   ├── processes.ts
│   │   │   ├── pfmea.ts
│   │   │   └── index.ts
│   │   ├── seed.ts            # Seed data
│   │   └── client.ts          # Database client
│   │
│   └── lib/                    # Shared utilities
│       ├── ap-calculator.ts   # AIAG-VDA 2019 AP logic
│       ├── validators.ts      # Zod schemas
│       └── utils.ts           # Helper functions
│
├── public/                     # Static assets
├── drizzle.config.ts          # Drizzle Kit config
├── next.config.js             # Next.js config
├── tailwind.config.ts         # Tailwind CSS config
├── .replit                    # Replit config
└── replit.nix                 # Nix environment
```

## 🔧 Key Technologies

| Technology | Purpose |
|------------|---------|
| **Next.js 14** | Full-stack React framework with App Router |
| **tRPC** | End-to-end type-safe API |
| **Drizzle ORM** | Type-safe database ORM |
| **PostgreSQL** | Relational database |
| **TypeScript** | Type safety across the stack |
| **Tailwind CSS** | Utility-first styling |
| **Zod** | Runtime validation |

## 📊 Database Schema

### Core Tables
- `customer_parts` - Customer part numbers and descriptions
- `processes` - Manufacturing process definitions
- `process_steps` - Individual operations in a process
- `pfmea_templates` - PFMEA templates by part/process
- `failure_modes` - Potential failure modes
- `control_plan_templates` - Control plan templates
- `characteristics` - Quality control characteristics

### Supporting Tables
- `process_versions` - Process version history
- `change_packages` - Engineering change management
- `signatures` - E-signature records
- `snapshots` - PDF snapshot metadata
- `auto_review_results` - Auto-review findings

## 🎮 Available Commands

```bash
# Development
npm run dev              # Start dev server
npm run build            # Production build
npm run start            # Start production server
npm run lint             # Run ESLint

# Database
npm run db:push          # Push schema changes
npm run db:generate      # Generate migrations
npm run db:studio        # Open Drizzle Studio
npm run db:seed          # Seed database

# Type Checking
npm run type-check       # TypeScript type check
```

## 🔐 Environment Variables

Required in Replit Secrets:

```env
DATABASE_URL=postgresql://...
NODE_ENV=development
```

Optional:

```env
NEXT_PUBLIC_APP_URL=https://your-app.repl.co
```

## 🎯 AIAG-VDA 2019 Compliance

This application implements the AIAG-VDA 2019 methodology:

### Action Priority (AP) Calculation
```
AP = Severity × (Occurrence + Detection + Prevention)
```

Where:
- **Severity**: Effect of failure (1-10)
- **Occurrence**: Likelihood of cause (1-10)
- **Detection**: Ability to detect (1-10)
- **Prevention**: Ability to prevent (1-10)

**Thresholds:**
- **High**: AP ≥ 100 (Requires immediate action)
- **Medium**: 50 ≤ AP < 100 (Action recommended)
- **Low**: AP < 50 (Monitor)

## 📝 Features

### ✅ Implemented
- [x] Database schema with 20+ tables
- [x] Seed data with realistic automotive examples
- [x] PFD (Process Flow Diagram) generator
- [x] PFMEA generator with AIAG-VDA compliance
- [x] Control Plan generator
- [x] Auto-Review engine with AP calculation
- [x] Basic UI pages (Home, Parts, Processes)
- [x] tRPC API with type safety
- [x] Drizzle ORM integration

### 🚧 In Progress
- [ ] Complete UI for PFMEA template builder
- [ ] Complete UI for Control Plan template builder
- [ ] Change Package workflow UI
- [ ] E-signature implementation
- [ ] PDF snapshot renderer with QR codes
- [ ] PDF export functionality
- [ ] Notification system
- [ ] MSA/Calibration integration

## 🐛 Troubleshooting

### Build Hangs
**Solution:** Clear the build cache
```bash
rm -rf .next node_modules
npm install
npm run build
```

### Database Connection Issues
**Solution:** Verify DATABASE_URL in Secrets
```bash
echo $DATABASE_URL
```

### Port Already in Use
**Solution:** Replit automatically handles ports, but if needed:
```bash
killall node
npm run dev
```

### TypeScript Errors
**Solution:** Regenerate types
```bash
npm run type-check
```

## 📚 Additional Resources

- [AIAG-VDA FMEA Handbook](https://www.aiag.org/quality/automotive-core-tools/fmea)
- [IATF 16949:2016 Standard](https://www.iatfglobaloversight.org/)
- [Next.js Documentation](https://nextjs.org/docs)
- [tRPC Documentation](https://trpc.io/docs)
- [Drizzle ORM Documentation](https://orm.drizzle.team/)

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section above
2. Review the PFMEA App Context document
3. Consult IATF 16949 and AIAG-VDA 2019 standards

## 📄 License

Proprietary - Internal Use Only

---

Built with ❤️ for automotive quality professionals
